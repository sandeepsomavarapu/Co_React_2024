import axios from "axios";
import { useEffect, useState } from "react";
import ShowData from "./ShowData";
import { Link } from "react-router-dom";

const Home = () => {
  const [data, setData] = useState([]);

  const Attr = ["ID", "Name", "Email", "Actions"];

  useEffect(() => {
    axios
      .get("http://localhost:3000/users")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
  return (
    <section>
      <div>
        <h1>List Of Users</h1>
        <button className="btn btn-dark">
            <Link to="/create">
            New
            </Link>
        </button>
      </div>
      <div>
        <ul className="list-group">
          {Attr.map((att) => (
            <li classname="list-group-item" key={att}>{att}</li>
          ))}
        </ul>
      </div>

      {data.map((infos) => (
        <ShowData
          key={infos.id}
          id={infos.id}
          name={infos.name}
          gmail={infos.gmail}
        />
      ))}
    </section>
  );
};

export default Home;
