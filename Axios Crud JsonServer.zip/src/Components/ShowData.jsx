import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import axios from "axios";

const ShowData = ({ id, name, gmail }) => {
  const handleDelete = (id) => {
    const confirm = window.confirm("sure about it?");
    if (confirm) {
      axios
        .delete(`http://localhost:3000/users/${id}`)
        .then((res) => {
          // log the id here
          window.location.reload();
          console.log(res);
        })
        .catch((err) => console.log(err));
    }
    console.log(id);
  };

  return (
    <div>
      <div>
        <ul className="list-group">
          <li className="list-group-item">{id}</li>
          <li className="list-group-item">{name}</li>
          <li className="list-group-item">{gmail}</li>
        </ul>
      </div>
      <div>
        <Link to={`/update/${id}`}>
          <button className="btn btn-dark">UPDATE</button>
        </Link>
        <button className="btn btn-dark" onClick={() => handleDelete(id)}>
          DELETE
        </button>
      </div>
    </div>
  );
};

ShowData.propTypes = {
  id: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
  gmail: PropTypes.string.isRequired,
};

export default ShowData;
