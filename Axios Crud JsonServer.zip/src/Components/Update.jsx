import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Update = () => {
  const { id } = useParams();
  const [name, setName] = useState("");
  const [gmail, setGmail] = useState("");
  const homeMenu = useNavigate();

  useEffect(() => {
    axios
      .get(`http://localhost:3000/users/${id}`)
      .then((res) => {
        setName(res.data.name);
        setGmail(res.data.gmail);
      })
      .catch((err) => console.log(err));
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:3000/users/${id}`, { name, gmail })
      .then((res) => {
        console.log(res);
        homeMenu("/");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      <div>
        <div>Update User</div>
        <form>
          <div>
            <label for="name">Your Name:</label>
            <input
              type="text"
              required
              placeholder="Enter Name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="email">Your Email:</label>
            <input
              type="email"
              required
              placeholder="Enter Email"
              name="email"
              value={gmail}
              onChange={(e) => setGmail(e.target.value)}
            />
          </div>
        </form>
        <div className="flex flex-row mt-8 mx-4">
          <button onClick={handleSubmit} type="submit">
            Update
          </button>

          <button>
            <Link to="/">Cancel</Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Update;
