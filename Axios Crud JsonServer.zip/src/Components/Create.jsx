import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Create = () => {
  const [values, setValues] = useState({
    name: '',
    gmail : ''
  })

  const navigate = useNavigate();
  const handleSubmit = () => {
    axios
      .post("http://localhost:3000/users", values)
      .then((res) => {
        console.log(res)
        navigate("/");
      })
      .catch((err) => console.log(err));

  }

  return (
    <div align="center">
      <div className="container">
        <div className="btn btn-success">Add New User</div>
        <form className="form-group" >
          <div>
          <label for="name">Name:</label>
            <input class="form-control" onChange={e => setValues({...values, name : e.target.value})} type="text" required  placeholder="Enter Name" name="name" className="w-64 h-7 rounded-xl px-2"/>
          </div>

          <div>
          <label for="email">Email:</label>
            <input class="form-control" onChange={e => setValues({...values, gmail : e.target.value})} type="email" required  placeholder="Enter Email" name="name" className="w-64 h-7 rounded-xl px-2"/>
          </div>

        </form>
        <div>
          <button className="btn btn-primary" onClick={handleSubmit}>
            Submit
          </button> 
          <button className="btn btn-primary">
            <Link to="/" style={{color:"white"}}>Cancel</Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Create;
