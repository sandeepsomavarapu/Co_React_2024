import axios from "axios";
import React from "react";
const baseURL = "https://jsonplaceholder.typicode.com/posts/1";
const jsonUserUrl="http://localhost:8000/users/222";

const Fetch = () => {
    const [post, setPost] = React.useState(null);
    const [user, setUser] = React.useState(null);
    React.useEffect(() => {
        axios.get(baseURL).then((response) => {
          setPost(response.data);
        });
      }, []);
      React.useEffect(() => {
        axios.get(jsonUserUrl).then((response) => {
          setUser(response.data);
        });
      }, []);
      if (!post) return null;
      return (
        <div align="center"><h2>Post Info: </h2>
          <p>{post.title}</p>
          <p>{post.body}</p>

          <h2>User Info: </h2>
          <p>{user.id}</p>
          <p>{user.name}</p>
          <p>{user.email}</p>
        </div>
      );
    }
export default Fetch;