import axios from "axios";
import React from "react";
const jsonUserUrl="http://localhost:8000/users/";
const Insert1=()=> {
  const createPost= ()=> {
    console.log("post")
    axios.post(jsonUserUrl, {
        id: 129,
        name:"rahul",
        email:"rahul@gmail.com"
      })
      .then((response) => {
        console.log("Data Posted..."+response.data)
      });
  }
  return (
    <div>
      <button onClick={createPost}>Create Post1</button>
    </div>
  );
}
export default Insert1;
