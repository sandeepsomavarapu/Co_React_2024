import logo from './logo.svg';
import './App.css';
import Fetch from './AxiosExamples/Fetch'
import Insert from './AxiosExamples/Insert';
import Insert1 from './AxiosExamples/Insert1';
import Merge from './AxiosExamples/Merge';
import Remove from './AxiosExamples/Remove';
import AxiosInstance from './AxiosExamples/AxiosInstance';
import ErrorHandling from './AxiosExamples/ErrorHandling';
import { BrowserRouter, Route, Routes } from "react-router-dom"
import 'bootstrap/dist/css/bootstrap.min.css'
import Home from "./Components/Home"
import Create from "./Components/Create"
import Update from "./Components/Update"
function App() {
  return (
    <div align="center">
    <BrowserRouter>
     <Routes>
        <Route path="/" element={<Home />} >
        </Route>
        <Route path="/create" element={<Create />} >
        </Route>
        <Route path="/update/:id" element={<Update />} >
        </Route>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
