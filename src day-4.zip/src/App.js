import logo from './logo.svg';
import './App.css';
import  FunctionalCompo from './FunctionalCompo';
import ClassCompo from './ClassCompo';
import Form from './Form';

function App() {
  return (
    <div className="App">
     {/* <FunctionalCompo orgname="coforge" location="hyd"></FunctionalCompo>
     <ClassCompo name="suresh"></ClassCompo> */}

     <Form></Form>
    </div>
  );
}

export default App;
