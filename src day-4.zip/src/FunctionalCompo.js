import React from 'react'

function FunctionalCompo(props) {

    function handleClick()
    {
        alert("Button Clicked")
    }
    return (
    <div>
        <h1>Functional Component :{props.orgname}{props.location}</h1>
       <button type="button" onClick={handleClick}>Click Here</button>
       
       
        {/* props are immutable we cannot update */}
        {/* {props.orgname = "cts"}
        <p>{props.orgname}</p> */}


    </div>
    )
}
export default FunctionalCompo;

//ctr+a -->ctrl+k,ctrl+f
//ctrl+/-->for comment