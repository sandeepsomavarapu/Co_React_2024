import React, { Component } from 'react'
export default class Form extends Component {
    constructor(props) {
      super(props)
      this.state = {
         username:""
      }
    }
    userNameHandle = (event) => {
        this.setState({username:event.target.value})
        console.log(this.state.username)
    }
    render() {
        return (
            <div>
                <form onSubmit={this.validate}>
                    Username: <input type='text' name='uname' onChange={this.userNameHandle} /><br />
                            <input type="submit" value="Login"></input>
                </form>
            </div>
        )
    }
}
