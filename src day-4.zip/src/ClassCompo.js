import { Component } from "react";
//rcc
class ClassCompo extends Component {
//rconst
    constructor(props) {
        super(props)
        //state is muttable(updatable)
        this.state = {
            name:"mahesh",
            clgname:"SHS",
            isPresent:false
        }
       // this.stateHandle=this.stateHandle.bind(this)
    }
    clickHandle() {
        console.log("Button is Clicked",this)
            }
    // stateHandle() {
    //     console.log("Present Button is Clicked")
    //     this.setState(
    //         {
    //         isPresent:!this.state.isPresent
    //         }
    //     )
    //     console.log(this.state)
    // }
        stateHandle=() =>{
        console.log("Present Button is Clicked")
        this.setState(
            {
            isPresent:!this.state.isPresent
            }
        )
        console.log(this.state.isPresent)
    }
    render() {
        return (
            <div>
                <h2>Class Component Props:{this.props.name}</h2>
                <button type="button" onClick={this.clickHandle}>Click here</button>
                <button type="button" onClick={this.stateHandle}>Present</button>
                {/* <button type="button" onClick={()=>this.stateHandle()}>Present</button> */}
            </div>
        )
    }
}
export default ClassCompo;