

import { useState } from "react";
import Button from "./Component/Button/button";
import Text from "./Component/Text/Text";

const App = () => {
    const [toggle, setToggle] = useState(true);

    return (
        <div className="App">
            <Text toggle={toggle} displayTxt="GeeksForGeeks" />
            <Button setToggle={setToggle} btnTxt="Toggle Text" />
        </div>
    );
}

export default App;